safeSeparate.mel  v1.0  (21 Oct 1999)

MEL script for Maya

by Bryan Ewert
   http://www.ewertb.com
   bryan@ewertb.com

   H2O Entertainment Corporation
   Vancouver, Canada
   http://www.h2oent.com

Preamble:
  Polygon ColorPerVertex is not preserved properly when performing
  Edit Polygons -> Extract and Edit Polygons -> Separate commands.
  This makes it difficult to split objects that already have
  Color Per Vertex applied.

Function:
  This script performs a long-hand approach to splitting an object
  apart:  Dupe the object, delete the selected facets from the 
  original and delete the opposite of the selected facets from
  the duplicate.  This method preserves the Color Per Vertex
  information.

Usage
  Select any number of face components.  Faces may be selected
  on more than one object; in this case, a separation will be performed
  on all affected objects.  Faces do not need to be selected in
  a contiguous block.  If you select all faces for an object then
  no action is taken for that object.

  Lastly, call this script.  Each affected object will be separated
  into two objects.  The newly created object will contain only the
  selected faces; the original object will contain all except the
  selected faces.  The newly created object will be the same as the
  original with the addition of a numeric decoration.
